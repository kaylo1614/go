import asyncio  # ⭐️ 新增：引用非同步模組
import pygame
import sys
import engine   # 引用核心

# 引用 engine 中的常數
BOARD_SIZE = engine.BOARD_SIZE
BLACK = engine.BLACK
WHITE = engine.WHITE
EMPTY = engine.EMPTY

# ==========================================
# UI 專屬常數
# ==========================================
CELL_SIZE = 60
MARGIN = 40
VIRTUAL_WIDTH = CELL_SIZE * (BOARD_SIZE - 1) + MARGIN * 2  # 560
PANEL_HEIGHT = 220 
VIRTUAL_HEIGHT = VIRTUAL_WIDTH + PANEL_HEIGHT              # 780

BACKGROUND_COLOR = (220, 179, 92)
GRID_COLOR = (0, 0, 0)
BLACK_STONE = (10, 10, 10)
WHITE_STONE = (245, 245, 245)

CARD_W, CARD_H = 100, 130
CARD_BG_COLOR = (245, 235, 210) 
CARD_BORDER_COLOR = (60, 40, 20)
SELECTED_COLOR = (255, 215, 0) 
DISCARD_SEL_COLOR = (255, 80, 80)
MANA_COLOR = (65, 105, 225)     

class GoUI:
    def __init__(self, game_state):
        pygame.init()
        pygame.display.set_caption("烏鷺爭霸 Web v1.9")
        
        # 網頁版視窗設定
        self.screen_w = VIRTUAL_WIDTH
        self.screen_h = VIRTUAL_HEIGHT
        self.screen = pygame.display.set_mode((self.screen_w, self.screen_h), pygame.RESIZABLE)
        self.virtual_surface = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT))
        
        self.game = game_state
        self.tf = engine.CardTransformer()
        
        self.font = pygame.font.SysFont("Arial", 18)
        self.card_font = pygame.font.SysFont("Microsoft JhengHei", 16, bold=True)
        self.title_font = pygame.font.SysFont("Microsoft JhengHei", 20, bold=True)
        self.mana_font = pygame.font.SysFont("Arial", 20, bold=True)
        
        self.scale_factor = 1.0
        self.offset_x = 0
        self.offset_y = 0

    def update_scale(self):
        # 取得當前視窗(或瀏覽器畫布)大小
        w, h = self.screen.get_size()
        scale_w = w / VIRTUAL_WIDTH
        scale_h = h / VIRTUAL_HEIGHT
        self.scale_factor = min(scale_w, scale_h)
        new_w = int(VIRTUAL_WIDTH * self.scale_factor)
        new_h = int(VIRTUAL_HEIGHT * self.scale_factor)
        self.offset_x = (w - new_w) // 2
        self.offset_y = (h - new_h) // 2

    def mouse_to_virtual(self, pos):
        x, y = pos
        vx = (x - self.offset_x) / self.scale_factor
        vy = (y - self.offset_y) / self.scale_factor
        return int(vx), int(vy)

    def draw_all(self, selected_id, possible_variants, step_idx, origin, mode, discard_selection, has_acted):
        self.virtual_surface.fill(BACKGROUND_COLOR)
        
        # 1. 棋盤
        for i in range(BOARD_SIZE):
            pygame.draw.line(self.virtual_surface, GRID_COLOR, (MARGIN, MARGIN + i * CELL_SIZE), (VIRTUAL_WIDTH - MARGIN, MARGIN + i * CELL_SIZE))
            pygame.draw.line(self.virtual_surface, GRID_COLOR, (MARGIN + i * CELL_SIZE, MARGIN), (MARGIN + i * CELL_SIZE, VIRTUAL_WIDTH - MARGIN))
        
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                if self.game.board[r, c] != engine.EMPTY:
                    color = BLACK_STONE if self.game.board[r, c] == engine.BLACK else WHITE_STONE
                    pygame.draw.circle(self.virtual_surface, color, (MARGIN + c * CELL_SIZE, MARGIN + r * CELL_SIZE), 25)

        # 2. 預覽
        real_mouse = pygame.mouse.get_pos()
        v_mouse = self.mouse_to_virtual(real_mouse)
        b_pos = self.get_board_pos(v_mouse)

        if not has_acted:
            if mode == "card" and selected_id and step_idx == 0 and b_pos:
                r, c = b_pos; self.draw_ghost_stone(r, c)
            elif mode == "card" and step_idx > 0 and origin:
                next_steps = set()
                for variant in possible_variants:
                    if step_idx < len(variant):
                        rel_r, rel_c = variant[step_idx]
                        next_steps.add((origin[0] + rel_r, origin[1] + rel_c))
                for nr, nc in next_steps:
                    if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE:
                        s = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
                        pygame.draw.rect(s, (255, 255, 0, 150), (5, 5, CELL_SIZE-10, CELL_SIZE-10), 3)
                        self.virtual_surface.blit(s, (MARGIN + nc * CELL_SIZE - CELL_SIZE//2, MARGIN + nr * CELL_SIZE - CELL_SIZE//2))

        # 3. UI 面板
        panel_y = VIRTUAL_WIDTH
        pygame.draw.rect(self.virtual_surface, (50, 50, 55), (0, panel_y, VIRTUAL_WIDTH, PANEL_HEIGHT))
        
        curr_p = self.game.current_player
        deck_count = len(self.game.decks[curr_p])
        
        if mode == "dead_marking":
            status = "【清理死子】點擊移除 -> 按結算"
            col = (255, 100, 100)
        elif mode == "discard_mana":
            status = f"【棄牌換能量】請選 2 張不要的牌 ({len(discard_selection)}/2)"
            col = (100, 255, 255)
        elif mode == "discard_card":
            status = f"【棄牌換牌】請選 2 張不要的牌 ({len(discard_selection)}/2)"
            col = (100, 255, 100)
        elif has_acted:
            status = f"{'黑方' if curr_p==BLACK else '白方'} | 已行動 | 可交易或結束"
            col = (255, 255, 100)
        else:
            status = f"{'黑方' if curr_p==BLACK else '白方'} | 請落子(單子/卡牌) 或 虛手"
            col = (255, 255, 255)
        
        status_full = f"{status} | 寶石:{self.game.mana[curr_p]} 牌:{deck_count}"
        self.virtual_surface.blit(self.card_font.render(status_full, True, col), (20, panel_y + 10))
        
        # 按鈕區
        btn_y = panel_y + 40
        btn_w, gap, start_x = 120, 15, 20
        
        trade_active = has_acted and mode != "dead_marking"
        
        rect1 = pygame.Rect(start_x, btn_y, btn_w, 30)
        col1 = (50, 100, 180) if trade_active else (80, 80, 80)
        if mode == "discard_mana": col1 = (100, 150, 255)
        self.draw_btn("換能量(棄2)", rect1, col1, active=trade_active)

        rect2 = pygame.Rect(start_x + btn_w + gap, btn_y, btn_w, 30)
        col2 = (50, 180, 100) if trade_active else (80, 80, 80)
        if mode == "discard_card": col2 = (100, 255, 150)
        self.draw_btn("換牌(棄2)", rect2, col2, active=trade_active)
        
        rect3 = pygame.Rect(start_x + (btn_w + gap)*2, btn_y, btn_w, 30)
        pass_txt = "結束回合" if has_acted else "虛手(Pass)"
        pass_col = (200, 100, 50) if has_acted else (160, 60, 60)
        self.draw_btn(pass_txt, rect3, pass_col, active=True)

        rect4 = pygame.Rect(start_x + (btn_w + gap)*3, btn_y, btn_w, 30)
        score_col = (200, 60, 60) if mode == "dead_marking" else (60, 160, 60)
        score_txt = "確認結算" if mode == "dead_marking" else "結算(Score)"
        self.draw_btn(score_txt, rect4, score_col, active=True)

        # 手牌
        hand_y = panel_y + 80
        for i, card_id in enumerate(self.game.hand[self.game.current_player]):
            x = start_x + i * 110
            is_sel = (selected_id == card_id and mode == "card")
            is_discard_sel = (i in discard_selection)
            dimmed = has_acted and mode not in ["discard_mana", "discard_card"]
            self.draw_card_visual(x, hand_y, card_id, is_sel, is_discard_sel, dimmed)

        if mode == "game_over":
            self.draw_game_over()
            
        # 縮放至全螢幕
        self.update_scale()
        scaled = pygame.transform.scale(self.virtual_surface, 
                                      (int(VIRTUAL_WIDTH * self.scale_factor), 
                                       int(VIRTUAL_HEIGHT * self.scale_factor)))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, (self.offset_x, self.offset_y))

    def draw_btn(self, text, rect, color, active=True):
        if not active: color = (60, 60, 60) 
        pygame.draw.rect(self.virtual_surface, color, rect, border_radius=5)
        pygame.draw.rect(self.virtual_surface, (200,200,200) if active else (100,100,100), rect, width=1, border_radius=5)
        txt_col = (255, 255, 255) if active else (150, 150, 150)
        text_surf = self.card_font.render(text, True, txt_col)
        self.virtual_surface.blit(text_surf, (rect.centerx - text_surf.get_width()//2, rect.centery - text_surf.get_height()//2))

    def draw_card_visual(self, x, y, card_id, is_selected, is_discard_sel, dimmed=False):
        if card_id not in self.tf.db: return
        name_cn, cost, shape, _, _ = self.tf.db[card_id]
        rect = pygame.Rect(x, y, CARD_W, CARD_H)
        
        if is_discard_sel: border_col, w = DISCARD_SEL_COLOR, 4
        elif is_selected: border_col, w = SELECTED_COLOR, 4
        else: border_col, w = CARD_BORDER_COLOR, 2
        
        bg_c = CARD_BG_COLOR if not dimmed else (150, 140, 120)
        
        pygame.draw.rect(self.virtual_surface, bg_c, rect, border_radius=8)
        pygame.draw.rect(self.virtual_surface, border_col, rect, width=w, border_radius=8)
        
        name_surf = self.title_font.render(name_cn, True, (40, 40, 40))
        self.virtual_surface.blit(name_surf, (x + (CARD_W - name_surf.get_width())//2, y + 8))
        
        preview_cx = x + CARD_W // 2
        preview_cy = y + CARD_H // 2 + 10
        mini_cell = 12
        stone_fill = (20, 20, 20) if self.game.current_player == BLACK else (240, 240, 240)
        stone_border = None if self.game.current_player == BLACK else (20, 20, 20)

        for (dr, dc) in shape:
            sx, sy = preview_cx + dc * mini_cell, preview_cy + dr * mini_cell
            pygame.draw.circle(self.virtual_surface, stone_fill, (sx, sy), 5)
            if stone_border: pygame.draw.circle(self.virtual_surface, stone_border, (sx, sy), 5, 1)

        ax, ay = preview_cx + shape[0][1] * mini_cell, preview_cy + shape[0][0] * mini_cell
        pygame.draw.circle(self.virtual_surface, (255, 50, 50), (ax, ay), 2)
        
        mc = (x + 12, y + 12)
        pygame.draw.circle(self.virtual_surface, MANA_COLOR, mc, 14)
        pygame.draw.circle(self.virtual_surface, (255, 255, 255), mc, 14, 2)
        cost_surf = self.mana_font.render(str(cost), True, (255, 255, 255))
        self.virtual_surface.blit(cost_surf, (mc[0] - cost_surf.get_width()//2, mc[1] - cost_surf.get_height()//2))

    def draw_game_over(self):
        b, w, win = self.game.calculate_score()
        ov = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 210))
        self.virtual_surface.blit(ov, (0, 0))
        res = [f"=== 數子法結算 ===", f"結果: {win}", f"黑方: {b:.1f}", f"白方: {w:.1f} (貼 {engine.KOMI})", "(點擊畫面重開)"]
        for i, t in enumerate(res):
            color = (255, 215, 0) if i < 2 else (200, 200, 200)
            ts = self.card_font.render(t, True, color)
            tr = ts.get_rect(center=(VIRTUAL_WIDTH//2, VIRTUAL_HEIGHT//2 - 80 + i * 40))
            self.virtual_surface.blit(ts, tr)
            
    def draw_ghost_stone(self, r, c):
        s = pygame.Surface((50, 50), pygame.SRCALPHA)
        color = (0,0,0,120) if self.game.current_player == engine.BLACK else (255,255,255,120)
        pygame.draw.circle(s, color, (25, 25), 25)
        self.virtual_surface.blit(s, (MARGIN + c * CELL_SIZE - 25, MARGIN + r * CELL_SIZE - 25))

    def get_board_pos(self, v_pos):
        c = round((v_pos[0] - MARGIN) / CELL_SIZE)
        r = round((v_pos[1] - MARGIN) / CELL_SIZE)
        return (r, c) if 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE else None

# ==========================================
# ⭐️ 異步主程式 (Async Main Loop)
# ==========================================
async def main():
    game = engine.CardGoState()
    tf = engine.CardTransformer()
    ui = GoUI(game)
    
    sel_id = None
    current_mode = "single" 
    possible_variants = [] 
    step_idx = 0           
    origin_pos = None      
    discard_selection = set()
    has_acted = False

    panel_y = VIRTUAL_WIDTH
    btn_y = panel_y + 40
    btn_w, gap, start_x = 120, 15, 20
    
    trade_mana_rect = pygame.Rect(start_x, btn_y, btn_w, 30)
    trade_card_rect = pygame.Rect(start_x + btn_w + gap, btn_y, btn_w, 30)
    pass_rect = pygame.Rect(start_x + (btn_w + gap)*2, btn_y, btn_w, 30)
    score_rect = pygame.Rect(start_x + (btn_w + gap)*3, btn_y, btn_w, 30)
    hand_y = panel_y + 80

    while True:
        ui.draw_all(sel_id, possible_variants, step_idx, origin_pos, current_mode, discard_selection, has_acted)
        pygame.display.flip()
        
        # ⭐️ 關鍵：讓出控制權給瀏覽器，避免卡死
        await asyncio.sleep(0)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            
            # 手機/網頁版 不需要 F11
            # 取消邏輯
            if (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE) or \
               (event.type == pygame.MOUSEBUTTONDOWN and event.button == 3):
                if step_idx > 0: game.rollback()
                sel_id = None; current_mode = "single"; step_idx = 0; origin_pos = None; possible_variants = []
                discard_selection = set()
                continue
            
            # 觸控/滑鼠點擊
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # 自動轉虛擬座標 (手機觸控也算滑鼠左鍵)
                m_pos = ui.mouse_to_virtual(event.pos)
                
                if current_mode == "game_over":
                    game = engine.CardGoState(); ui.game = game; current_mode = "single"; has_acted = False; continue

                if pass_rect.collidepoint(m_pos) and step_idx == 0:
                    if not has_acted:
                        game.start_turn()
                        game.execute_move(action_type='pass')
                        game.switch_player() 
                    else:
                        game.switch_player()
                        has_acted = False
                    current_mode = "single"; sel_id = None; discard_selection.clear(); continue

                trade_enabled = has_acted and current_mode != "dead_marking"
                if trade_mana_rect.collidepoint(m_pos) and step_idx == 0 and trade_enabled:
                    current_mode = "single" if current_mode == "discard_mana" else "discard_mana"
                    discard_selection.clear(); continue
                
                if trade_card_rect.collidepoint(m_pos) and step_idx == 0 and trade_enabled:
                    current_mode = "single" if current_mode == "discard_card" else "discard_card"
                    discard_selection.clear(); continue

                if score_rect.collidepoint(m_pos) and step_idx == 0:
                    current_mode = "dead_marking" if current_mode != "dead_marking" else "game_over"
                    sel_id = None; continue

                if current_mode == "dead_marking":
                    b_pos = ui.get_board_pos(m_pos)
                    if b_pos: game.remove_dead_group(b_pos[0], b_pos[1])
                    continue

                if m_pos[1] > hand_y and step_idx == 0:
                    idx = (m_pos[0] - 20) // 110
                    if 0 <= idx < len(game.hand[game.current_player]):
                        if current_mode in ["discard_mana", "discard_card"]:
                            if idx in discard_selection: discard_selection.remove(idx)
                            else:
                                discard_selection.add(idx)
                                if len(discard_selection) == 2:
                                    target = 'mana' if current_mode == "discard_mana" else 'card'
                                    if game.trade_resources(list(discard_selection), target):
                                        current_mode = "single"; discard_selection.clear()
                        elif not has_acted:
                            sel_id = game.hand[game.current_player][idx]
                            possible_variants = tf.get_all_variants(sel_id) 
                            step_idx = 0; current_mode = "card"; discard_selection.clear()
                
                elif current_mode in ["single", "card"] and not has_acted:
                    b_pos = ui.get_board_pos(m_pos)
                    if b_pos:
                        r, c = b_pos
                        if current_mode == "single":
                            if game.is_legal(r, c, game.current_player):
                                game.start_turn()
                                game.board[r, c] = game.current_player
                                game.process_capture(r, c)
                                game.execute_move(action_type='single')
                                has_acted = True

                        elif current_mode == "card" and sel_id:
                            if step_idx == 0:
                                cost = tf.db[sel_id][1]
                                if game.mana[game.current_player] >= cost and game.is_legal(r, c, game.current_player):
                                    valid = [v for v in possible_variants if v[0] == (0,0)]
                                    if valid:
                                        game.start_turn()
                                        game.mana[game.current_player] -= cost
                                        game.board[r, c] = game.current_player
                                        game.process_capture(r, c)
                                        origin_pos = (r, c); possible_variants = valid; step_idx = 1
                                        if all(len(v) == 1 for v in possible_variants):
                                            game.execute_move(action_type='card', used_card=sel_id)
                                            current_mode = "single"; sel_id = None; step_idx = 0; has_acted = True
                            else:
                                next_v = []
                                for v in possible_variants:
                                    if step_idx < len(v):
                                        tr, tc = origin_pos[0]+v[step_idx][0], origin_pos[1]+v[step_idx][1]
                                        if (r, c) == (tr, tc): next_v.append(v)
                                if next_v:
                                    if game.is_legal(r, c, game.current_player):
                                        game.board[r, c] = game.current_player
                                        game.process_capture(r, c)
                                        possible_variants = next_v; step_idx += 1
                                        if step_idx >= len(possible_variants[0]):
                                            game.execute_move(action_type='card', used_card=sel_id)
                                            current_mode = "single"; sel_id = None; step_idx = 0; origin_pos = None; has_acted = True
                                    else:
                                        game.rollback(); step_idx = 0; current_mode = "single"; sel_id = None

# 執行非同步主程式
if __name__ == "__main__":
    asyncio.run(main())
